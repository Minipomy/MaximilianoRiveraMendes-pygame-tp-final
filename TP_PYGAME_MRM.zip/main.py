from Menu import Menu
from constants import DATA 

if __name__ == "__main__":
    menu = Menu(DATA)
    menu.main_menu()